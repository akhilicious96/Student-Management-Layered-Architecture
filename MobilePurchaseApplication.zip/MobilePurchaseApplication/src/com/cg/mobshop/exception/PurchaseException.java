package com.cg.mobshop.exception;
public class PurchaseException extends Exception {

	public PurchaseException(String msg){
		super(msg);
	}
}
